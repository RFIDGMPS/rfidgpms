<div class="container-fluid pt-4 px-4" style="margin-top: 60%">
               <div class="bg-light rounded-top p-4">
                  <div class="row">
                     <div class="col-12 col-sm-6 text-center text-sm-start"> &copy; <a href="#">2024</a>, All Right Reserved. </div>
                     <div class="col-12 col-sm-6 text-center text-sm-end"> Created By <a href="#">RFID-Based Gate Pass Management System</a>
                     </div>
                  </div>
               </div>
            </div>
         </div>